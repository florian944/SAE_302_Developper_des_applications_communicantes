/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.saeappli;

/**
 *
 * @author tp
 */
public class Saeappli {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}