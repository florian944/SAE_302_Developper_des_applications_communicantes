package com.mycompany.saeappli;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.util.ArrayList;

// --- CLASSE MESSAGE (On la garde pour compatibilité mais on utilise ArrayList mnt) ---
class Message {
    String msg; boolean envoye, recu;
    Message(String m, boolean e) { msg = m; envoye = e; recu = false; }
    public String toString() { return msg; }
}

// --- CLASSE GROUPE ---
class Groupe {
    String nomGroupe;
    ArrayList<String> membres;
    ArrayList<String> discussion;

    Groupe(String nom, String createur) {
        nomGroupe = nom;
        membres = new ArrayList<>();
        membres.add(createur);
        discussion = new ArrayList<>();
    }

    void ajouteMembre(String n) {
        if (!membres.contains(n)) membres.add(n);
    }

    void ajouterMessage(String auteur, String message) {
        discussion.add(auteur + ": " + message);
    }

    String getHistorique() {
        if (discussion.isEmpty()) return "vide";
        return String.join("|", discussion);
    }
}

// --- CLASSE AMI (MODIFIÉE POUR LE CHAT) ---
class Ami {
    String login;
    boolean accepte;
    // MODIFICATION ICI : On utilise une liste comme pour les groupes
    ArrayList<String> conversationPrivee;

    Ami(String a) {
        login = a;
        accepte = false;
        conversationPrivee = new ArrayList<>();
    }

    boolean estAccepte() { return accepte; }
    void accepte() { accepte = true; }

    // Nouvelle fonction pour ajouter un message privé
    void ajouterMessagePrive(String msg) {
        conversationPrivee.add(msg);
    }

    String getHistorique() {
        if (conversationPrivee.isEmpty()) return "";
        return String.join("|", conversationPrivee);
    }
}

// --- CLASSE UTILISATEUR ---
class Utilisateur {
    String login, pwd;
    Ami a[];
    int nbAmi;
    boolean connecte;

    public Utilisateur(String l, String p) {
        login = l;
        pwd = p;
        nbAmi = 0;
        a = new Ami[50]; // Max 50 amis
        connecte = false;
    }

    boolean estConnecte() { return connecte; }
    void connecte() { connecte = true; }
    void deconnecte() { connecte = false; }

    void nouvelAmi(String ami) {
        if (nbAmi < 50) {
            a[nbAmi] = new Ami(ami);
            nbAmi++;
        }
    }

    void retirerAmi(String nom) {
        int idx = -1;
        for(int i=0; i<nbAmi; i++) if(a[i].login.equals(nom)) idx=i;
        if(idx!=-1) {
            for(int i=idx; i<nbAmi-1; i++) a[i]=a[i+1];
            nbAmi--;
        }
    }
    
    // Helper pour trouver l'objet Ami correspondant à un login
    Ami getAmiObj(String nomAmi) {
        for(int i=0; i<nbAmi; i++) {
            if(a[i].login.equals(nomAmi)) return a[i];
        }
        return null;
    }
}

// --- SERVEUR PRINCIPAL ---
public class ServeurSocial {
    static final int port = 3333;
    DatagramSocket socket;
    DatagramPacket recu;

    Utilisateur u[] = new Utilisateur[50];
    int nbUtilisateur = 0;
    ArrayList<Groupe> lesGroupes = new ArrayList<>();

    ServeurSocial() throws SocketException, IOException {
        System.out.println("--- SERVEUR EN LIGNE (Port " + port + ") ---");
        socket = new DatagramSocket(port);
        byte[] buffer = new byte[4096]; // Buffer augmenté encore plus

        for (;;) {
            recu = new DatagramPacket(buffer, buffer.length);
            socket.receive(recu);
            String s = new String(recu.getData(), 0, recu.getLength()).trim();
            System.out.println("Recu : [" + s + "]");

            // On split en limitant à 4 parties max pour ne pas couper les messages qui contiennent des virgules
            String t[] = s.split(",", 4);
            if (t.length < 1) continue;

            String commande = t[0];

            // 1. INSCRIPTION
            if (commande.equals("inscription") && t.length >= 2) {
                if (nbUtilisateur < 50) {
                    boolean present = false;
                    for (int i = 0; i < nbUtilisateur; i++) if (u[i].login.equals(t[1])) present = true;
                    if (!present) {
                        String pass = (t.length > 2) ? t[2] : "";
                        u[nbUtilisateur] = new Utilisateur(t[1], pass);
                        nbUtilisateur++;
                        envoi("inscription_ok");
                    } else envoi("erreur_pseudo_pris");
                } else envoi("erreur_serveur_plein");
            }

            // 2. CONNEXION
            else if (commande.equals("connexion") && t.length >= 2) {
                boolean trouve = false;
                for (int i = 0; i < nbUtilisateur; i++) {
                    if (u[i].login.equals(t[1])) {
                        String passRecu = (t.length > 2) ? t[2] : "";
                        if (u[i].pwd.equals(passRecu)) {
                            u[i].connecte();
                            envoi("connexion_ok");
                        } else envoi("erreur_mdp");
                        trouve = true; break;
                    }
                }
                if (!trouve) envoi("erreur_compte_inconnu");
            }

            // 3. DECONNEXION
            else if (commande.equals("deconnexion") && t.length >= 2) {
                for (int i = 0; i < nbUtilisateur; i++) if (u[i].login.equals(t[1])) u[i].deconnecte();
            }

            // 4. LECTURE (POLLING) - Modifié pour ne pas bloquer
            else if (commande.equals("lecture") && t.length >= 2) {
                String reponse = "rien";
                String demandeur = t[1];
                for (int i = 0; i < nbUtilisateur; i++) {
                    if (u[i].login.equals(demandeur)) {
                        for (int j = 0; j < u[i].nbAmi; j++) {
                            if (!u[i].a[j].estAccepte()) { reponse = "Demande ami de: " + u[i].a[j].login; break; }
                        }
                    }
                }
                envoi(reponse);
            }

            // 5. LISTE AMIS
            else if (commande.equals("liste_amis") && t.length >= 2) {
                String reponse = "liste_amis_reponse";
                for (int i = 0; i < nbUtilisateur; i++) {
                    if (u[i].login.equals(t[1])) {
                        for (int j = 0; j < u[i].nbAmi; j++) if (u[i].a[j].estAccepte()) reponse += "," + u[i].a[j].login;
                    }
                }
                envoi(reponse);
            }

            // --- GESTION GROUPES ---

            else if (commande.equals("creer_groupe") && t.length >= 3) {
                lesGroupes.add(new Groupe(t[2], t[1]));
                envoi("groupe_cree");
            }

            else if (commande.equals("ajouter_membre_groupe") && t.length >= 3) {
                for (Groupe g : lesGroupes) if (g.nomGroupe.equals(t[1])) g.ajouteMembre(t[2]);
            }

            else if (commande.equals("req_mes_groupes") && t.length >= 2) {
                String demandeur = t[1];
                String reponse = "mes_groupes_reponse";
                for(Groupe g : lesGroupes) {
                    if(g.membres.contains(demandeur)) reponse += "," + g.nomGroupe;
                }
                envoi(reponse);
            }

            else if (commande.equals("envoyer_msg_groupe") && t.length >= 4) {
                // t[1]=Login, t[2]=Groupe, t[3]=Message
                for (Groupe g : lesGroupes) {
                    if (g.nomGroupe.equals(t[2])) g.ajouterMessage(t[1], t[3]);
                }
            }

            else if (commande.equals("req_msg_groupe") && t.length >= 2) {
                String nomGrp = t[1];
                String reponse = "rep_msg_groupe";
                for (Groupe g : lesGroupes) {
                    if (g.nomGroupe.equals(nomGrp)) {
                        String histo = g.getHistorique();
                        if (!histo.equals("vide")) reponse += "," + histo;
                    }
                }
                envoi(reponse);
            }

            // --- NOUVEAU : GESTION MESSAGES PRIVES ---

            // Commande : envoyer_msg_prive,MOI,AUTRE,MESSAGE
            else if (commande.equals("envoyer_msg_prive") && t.length >= 4) {
                String moi = t[1];
                String autre = t[2];
                String leMessage = t[3];

                String formatMessage = moi + ": " + leMessage; // Ex: "Toto: Salut ca va"

                // 1. Ajouter le message dans l'objet Ami de "Moi" (pour que je vois ce que j'ai écrit)
                for(int i=0; i<nbUtilisateur; i++) {
                    if(u[i].login.equals(moi)) {
                        Ami amiObj = u[i].getAmiObj(autre);
                        if(amiObj != null) amiObj.ajouterMessagePrive(formatMessage);
                    }
                }

                // 2. Ajouter le message dans l'objet Ami de "Autre" (pour qu'il le reçoive)
                for(int i=0; i<nbUtilisateur; i++) {
                    if(u[i].login.equals(autre)) {
                        Ami amiObj = u[i].getAmiObj(moi);
                        if(amiObj != null) amiObj.ajouterMessagePrive(formatMessage);
                    }
                }
                System.out.println("Msg privé de " + moi + " à " + autre + " : " + leMessage);
            }

            // Commande : req_msg_prive,MOI,AUTRE
            else if (commande.equals("req_msg_prive") && t.length >= 3) {
                String moi = t[1];
                String autre = t[2];
                String reponse = "rep_msg_prive";

                for(int i=0; i<nbUtilisateur; i++) {
                    if(u[i].login.equals(moi)) {
                        Ami amiObj = u[i].getAmiObj(autre);
                        if(amiObj != null) {
                            reponse += "," + amiObj.getHistorique();
                        }
                    }
                }
                envoi(reponse);
            }

            // --- GESTION DEMANDES AMIS ---

            else if (commande.equals("demande_ami") && t.length >= 3) {
                String demandeur = t[1], cible = t[2];
                boolean trouve = false;
                for (int i = 0; i < nbUtilisateur; i++) {
                    if (u[i].login.equals(cible)) {
                        trouve = true;
                        boolean deja = false;
                        for(int j=0; j<u[i].nbAmi; j++) if(u[i].a[j].login.equals(demandeur)) deja = true;
                        if(!deja) { u[i].nouvelAmi(demandeur); envoi("demande_ami_ok"); }
                        else envoi("deja_ami");
                    }
                }
                if (!trouve) envoi("utilisateur_inconnu");
            }

            else if (commande.equals("demande_ami_accepte") && t.length >= 3) {
                String moi=t[1], autre=t[2];
                // Accepter coté MOI
                for(int i=0; i<nbUtilisateur; i++) {
                    if(u[i].login.equals(moi)) {
                        Ami a = u[i].getAmiObj(autre);
                        if(a!=null) a.accepte();
                    }
                }
                // Créer l'ami coté AUTRE et accepter direct
                for(int i=0; i<nbUtilisateur; i++) {
                    if(u[i].login.equals(autre)) {
                        u[i].nouvelAmi(moi);
                        Ami a = u[i].getAmiObj(moi);
                        if(a!=null) a.accepte();
                    }
                }
                envoi("ami_valide");
            }

            else if (commande.equals("demande_ami_refus") && t.length >= 3) {
                for(int i=0; i<nbUtilisateur; i++) if(u[i].login.equals(t[1])) u[i].retirerAmi(t[2]);
                envoi("ami_refuse");
            }
        }
    }

    void envoi(String msg) throws SocketException, IOException {
        byte[] message = msg.getBytes();
        DatagramPacket envoye = new DatagramPacket(message, message.length, recu.getAddress(), recu.getPort());
        socket.send(envoye);
    }

    public static void main(String[] args) throws SocketException, IOException { new ServeurSocial(); }
}