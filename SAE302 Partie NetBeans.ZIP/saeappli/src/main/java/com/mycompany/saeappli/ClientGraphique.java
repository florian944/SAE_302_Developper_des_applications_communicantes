package com.mycompany.saeappli;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.*;

public class ClientGraphique extends JFrame {

    // --- CONFIGURATION RESEAU ---
    static final int PORT_SERVEUR = 3333;
    static final String ADRESSE_IP = "127.0.0.1";
    DatagramSocket socket;
    InetAddress address;

    // --- ETAT DU CLIENT ---
    String monLogin = "";
    String selectionActuelle = null; // Peut être un ami ou un groupe
    boolean modeGroupe = false;      // True si on discute dans un groupe, False si ami
    Timer timerRafraichissement;

    // --- ELEMENTS GRAPHIQUES ---
    CardLayout cardLayout = new CardLayout();
    JPanel mainPanel = new JPanel(cardLayout);

    // Panel Connexion
    JTextField txtLogin = new JTextField(15);
    JPasswordField txtMdp = new JPasswordField(15);

    // Panel Chat
    JTabbedPane ongletsGauche = new JTabbedPane();
    
    // Liste Amis
    DefaultListModel<String> modelAmis = new DefaultListModel<>();
    JList<String> listAmis = new JList<>(modelAmis);
    
    // Liste Groupes
    DefaultListModel<String> modelGroupes = new DefaultListModel<>();
    JList<String> listGroupes = new JList<>(modelGroupes);

    JTextArea zoneChat = new JTextArea();
    JTextField txtMessage = new JTextField();
    JLabel lblTitreChat = new JLabel("Sélectionnez un ami ou un groupe");

    public ClientGraphique() {
        super("Messagerie Sociale - Amis & Groupes");
        setSize(900, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Initialisation Réseau
        try {
            socket = new DatagramSocket();
            address = InetAddress.getByName(ADRESSE_IP);
            socket.setSoTimeout(1000); 
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Erreur réseau : " + e.getMessage());
            System.exit(1);
        }

        // Construction des vues
        initVueConnexion();
        initVueChat();

        add(mainPanel);
        setVisible(true);
    }

    // -------------------------------------------------------------------------
    // VUE 1 : CONNEXION
    // -------------------------------------------------------------------------
    private void initVueConnexion() {
        JPanel panelConnexion = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        gbc.gridx = 0; gbc.gridy = 0;
        panelConnexion.add(new JLabel("Login :"), gbc);
        gbc.gridx = 1;
        panelConnexion.add(txtLogin, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        panelConnexion.add(new JLabel("Mot de passe :"), gbc);
        gbc.gridx = 1;
        panelConnexion.add(txtMdp, gbc);

        JPanel btnPanel = new JPanel();
        JButton btnConnect = new JButton("Connexion");
        JButton btnInscrip = new JButton("Inscription");
        btnPanel.add(btnConnect);
        btnPanel.add(btnInscrip);

        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 2;
        panelConnexion.add(btnPanel, gbc);

        btnConnect.addActionListener(e -> actionConnexion());
        btnInscrip.addActionListener(e -> actionInscription());

        mainPanel.add(panelConnexion, "LOGIN");
    }

    // -------------------------------------------------------------------------
    // VUE 2 : CHAT PRINCIPAL
    // -------------------------------------------------------------------------
    private void initVueChat() {
        JPanel panelChat = new JPanel(new BorderLayout());

        // --- GAUCHE : ONGLETS AMIS / GROUPES ---
        JPanel panelGauche = new JPanel(new BorderLayout());
        panelGauche.setPreferredSize(new Dimension(250, 0));

        // Onglet Amis
        listAmis.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane scrollAmis = new JScrollPane(listAmis);
        ongletsGauche.addTab("Mes Amis", scrollAmis);

        // Onglet Groupes
        listGroupes.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane scrollGroupes = new JScrollPane(listGroupes);
        ongletsGauche.addTab("Mes Groupes", scrollGroupes);

        panelGauche.add(ongletsGauche, BorderLayout.CENTER);

        // Boutons d'actions sous les listes
        JPanel panelBoutons = new JPanel(new GridLayout(3, 1, 5, 5));
        panelBoutons.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        
        JButton btnAjoutAmi = new JButton("Ajouter Ami");
        JButton btnCreerGroupe = new JButton("Créer Groupe");
        JButton btnAjoutMembre = new JButton("Ajouter Membre au Groupe");
        JButton btnDeconnexion = new JButton("Déconnexion");
        btnDeconnexion.setBackground(new Color(255, 200, 200));

        btnAjoutAmi.addActionListener(e -> actionAjouterAmi());
        btnCreerGroupe.addActionListener(e -> actionCreerGroupe());
        btnAjoutMembre.addActionListener(e -> actionAjouterMembreGroupe());
        btnDeconnexion.addActionListener(e -> actionDeconnexion());
        
        // On regroupe les boutons d'action
        JPanel subPanelAction = new JPanel(new GridLayout(1, 2));
        subPanelAction.add(btnAjoutAmi);
        subPanelAction.add(btnCreerGroupe);
        
        panelBoutons.add(subPanelAction);
        panelBoutons.add(btnAjoutMembre);
        panelBoutons.add(btnDeconnexion);

        panelGauche.add(panelBoutons, BorderLayout.SOUTH);

        // --- CENTRE : ZONE DE DISCUSSION ---
        JPanel panelCentre = new JPanel(new BorderLayout());
        lblTitreChat.setHorizontalAlignment(SwingConstants.CENTER);
        lblTitreChat.setFont(new Font("Arial", Font.BOLD, 14));
        lblTitreChat.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        
        zoneChat.setEditable(false);
        zoneChat.setLineWrap(true);
        zoneChat.setWrapStyleWord(true);
        zoneChat.setFont(new Font("Monospaced", Font.PLAIN, 12));
        
        panelCentre.add(lblTitreChat, BorderLayout.NORTH);
        panelCentre.add(new JScrollPane(zoneChat), BorderLayout.CENTER);

        // --- BAS : SAISIE ---
        JPanel panelBas = new JPanel(new BorderLayout());
        JButton btnEnvoyer = new JButton("Envoyer");
        panelBas.add(txtMessage, BorderLayout.CENTER);
        panelBas.add(btnEnvoyer, BorderLayout.EAST);
        panelCentre.add(panelBas, BorderLayout.SOUTH);

        // Assemblage
        panelChat.add(panelGauche, BorderLayout.WEST);
        panelChat.add(panelCentre, BorderLayout.CENTER);

        // --- GESTION DES EVENEMENTS ---

        // Changement d'onglet (Amis <-> Groupes)
        ongletsGauche.addChangeListener(e -> {
            if (ongletsGauche.getSelectedIndex() == 0) {
                // Mode AMIS
                listGroupes.clearSelection();
                if(listAmis.getSelectedValue() != null) {
                    selectionActuelle = listAmis.getSelectedValue();
                    modeGroupe = false;
                    lblTitreChat.setText("Discussion avec " + selectionActuelle);
                    chargerDiscussion();
                }
            } else {
                // Mode GROUPES
                listAmis.clearSelection();
                if(listGroupes.getSelectedValue() != null) {
                    selectionActuelle = listGroupes.getSelectedValue();
                    modeGroupe = true;
                    lblTitreChat.setText("Groupe : " + selectionActuelle);
                    chargerDiscussion();
                }
            }
        });

        // Clic sur liste Amis
        listAmis.addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && listAmis.getSelectedValue() != null) {
                selectionActuelle = listAmis.getSelectedValue();
                modeGroupe = false;
                lblTitreChat.setText("Discussion avec " + selectionActuelle);
                chargerDiscussion();
            }
        });

        // Clic sur liste Groupes
        listGroupes.addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && listGroupes.getSelectedValue() != null) {
                selectionActuelle = listGroupes.getSelectedValue();
                modeGroupe = true;
                lblTitreChat.setText("Groupe : " + selectionActuelle);
                chargerDiscussion();
            }
        });

        ActionListener envoyerListener = e -> actionEnvoyerMessage();
        btnEnvoyer.addActionListener(envoyerListener);
        txtMessage.addActionListener(envoyerListener);

        mainPanel.add(panelChat, "CHAT");
    }

    // -------------------------------------------------------------------------
    // LOGIQUE METIER
    // -------------------------------------------------------------------------

    private void actionInscription() {
        String l = txtLogin.getText();
        String p = new String(txtMdp.getPassword());
        if(l.isEmpty()) return;
        String reponse = envoyerRecevoir("inscription," + l + "," + p);
        if (reponse.equals("inscription_ok")) JOptionPane.showMessageDialog(this, "Compte créé !");
        else JOptionPane.showMessageDialog(this, "Erreur : " + reponse);
    }

    private void actionConnexion() {
        String l = txtLogin.getText();
        String p = new String(txtMdp.getPassword());
        String reponse = envoyerRecevoir("connexion," + l + "," + p);
        if (reponse.equals("connexion_ok")) {
            monLogin = l;
            txtMdp.setText("");
            cardLayout.show(mainPanel, "CHAT");
            demarrerPolling();
        } else {
            JOptionPane.showMessageDialog(this, "Erreur connexion : " + reponse);
        }
    }
    
    private void actionDeconnexion() {
        if (timerRafraichissement != null) timerRafraichissement.stop();
        envoyerSansAttente("deconnexion," + monLogin);
        monLogin = "";
        selectionActuelle = null;
        modelAmis.clear();
        modelGroupes.clear();
        zoneChat.setText("");
        cardLayout.show(mainPanel, "LOGIN");
    }

    // --- GESTION AMIS ---

    private void actionAjouterAmi() {
        String nom = JOptionPane.showInputDialog(this, "Pseudo de l'ami :");
        if (nom != null && !nom.isEmpty()) {
            String rep = envoyerRecevoir("demande_ami," + monLogin + "," + nom);
            JOptionPane.showMessageDialog(this, "Serveur : " + rep);
        }
    }

    // --- GESTION GROUPES ---

    private void actionCreerGroupe() {
        String nomGrp = JOptionPane.showInputDialog(this, "Nom du nouveau groupe :");
        if (nomGrp != null && !nomGrp.isEmpty()) {
            // creation_groupe,CREATEUR,NOM
            String rep = envoyerRecevoir("creer_groupe," + monLogin + "," + nomGrp);
            if(rep.equals("groupe_cree")) {
                rafraichirListes(); // Pour voir apparaître le groupe tout de suite
                JOptionPane.showMessageDialog(this, "Groupe '" + nomGrp + "' créé !");
            } else {
                JOptionPane.showMessageDialog(this, "Erreur création groupe.");
            }
        }
    }

    private void actionAjouterMembreGroupe() {
        if(!modeGroupe || selectionActuelle == null) {
            JOptionPane.showMessageDialog(this, "Veuillez sélectionner un groupe d'abord.");
            return;
        }
        String nouveauMembre = JOptionPane.showInputDialog(this, "Pseudo à ajouter au groupe " + selectionActuelle + " :");
        if (nouveauMembre != null && !nouveauMembre.isEmpty()) {
            // ajouter_membre_groupe,NOM_GROUPE,NOUVEAU_MEMBRE
            envoyerSansAttente("ajouter_membre_groupe," + selectionActuelle + "," + nouveauMembre);
            JOptionPane.showMessageDialog(this, "Invitation envoyée (si l'utilisateur existe).");
        }
    }

    // --- ENVOI MESSAGES (Privé ou Groupe) ---

    private void actionEnvoyerMessage() {
        if (selectionActuelle == null) {
            JOptionPane.showMessageDialog(this, "Sélectionnez un destinataire !");
            return;
        }
        String msg = txtMessage.getText();
        if (msg.isEmpty()) return;

        if (modeGroupe) {
            // Envoyer au GROUPE : envoyer_msg_groupe,LOGIN,NOM_GROUPE,MSG
            envoyerSansAttente("envoyer_msg_groupe," + monLogin + "," + selectionActuelle + "," + msg);
        } else {
            // Envoyer PRIVE : envoyer_msg_prive,MOI,AUTRE,MSG
            envoyerSansAttente("envoyer_msg_prive," + monLogin + "," + selectionActuelle + "," + msg);
        }
        
        txtMessage.setText("");
        chargerDiscussion();
    }

    // --- BOUCLE DE MISE A JOUR ---

    private void demarrerPolling() {
        timerRafraichissement = new Timer(2000, e -> {
            rafraichirListes();
            chargerDiscussion();
            verifierNotifications();
        });
        timerRafraichissement.start();
    }

    private void rafraichirListes() {
        // 1. Rafraichir AMIS
        String rep = envoyerRecevoir("liste_amis," + monLogin);
        if (rep.startsWith("liste_amis_reponse")) {
            majModel(modelAmis, rep, listAmis);
        }

        // 2. Rafraichir GROUPES
        // Commande : req_mes_groupes,LOGIN
        String repG = envoyerRecevoir("req_mes_groupes," + monLogin);
        // Attendu : mes_groupes_reponse,grp1,grp2
        if (repG.startsWith("mes_groupes_reponse")) {
             majModel(modelGroupes, repG, listGroupes);
        }
    }
    
    // Fonction utilitaire pour mettre à jour une JList sans perdre la sélection
    private void majModel(DefaultListModel<String> model, String repServeur, JList<String> list) {
        String selection = list.getSelectedValue();
        model.clear();
        String[] parts = repServeur.split(",");
        for (int i = 1; i < parts.length; i++) {
            if(!parts[i].trim().isEmpty()) model.addElement(parts[i]);
        }
        if (selection != null && model.contains(selection)) {
            list.setSelectedValue(selection, true);
        }
    }

    private void chargerDiscussion() {
        if (selectionActuelle == null) return;
        
        String rep;
        if (modeGroupe) {
            // Historique GROUPE : req_msg_groupe,NOM_GROUPE
            rep = envoyerRecevoir("req_msg_groupe," + selectionActuelle);
            // Attendu: rep_msg_groupe,msg1|msg2...
        } else {
            // Historique PRIVE : req_msg_prive,MOI,AUTRE
            rep = envoyerRecevoir("req_msg_prive," + monLogin + "," + selectionActuelle);
        }

        if (rep.startsWith("rep_msg_") || rep.startsWith("rep_msg_groupe")) {
            zoneChat.setText("");
            // Le prefixe peut varier légèrement en longueur donc on cherche la première virgule
            int premierVirgule = rep.indexOf(',');
            if (premierVirgule != -1 && premierVirgule < rep.length() - 1) {
                String contenu = rep.substring(premierVirgule + 1);
                String[] messages = contenu.split("\\|");
                for (String m : messages) {
                    zoneChat.append(m + "\n");
                }
                zoneChat.setCaretPosition(zoneChat.getDocument().getLength());
            }
        }
    }
    
    private void verifierNotifications() {
        String rep = envoyerRecevoir("lecture," + monLogin);
        if (rep.startsWith("Demande ami de:")) {
            timerRafraichissement.stop();
            String demandeur = rep.split(":")[1].trim();
            int choix = JOptionPane.showConfirmDialog(this, 
                "Demande d'ami de " + demandeur + ". Accepter ?", 
                "Nouvelle demande", JOptionPane.YES_NO_OPTION);
            
            if (choix == JOptionPane.YES_OPTION) {
                envoyerRecevoir("demande_ami_accepte," + monLogin + "," + demandeur);
            } else {
                envoyerRecevoir("demande_ami_refus," + monLogin + "," + demandeur);
            }
            timerRafraichissement.start();
        }
    }

    // --- OUTILS RESEAU ---

    private String envoyerRecevoir(String msg) {
        try {
            byte[] bufS = msg.getBytes();
            DatagramPacket packetS = new DatagramPacket(bufS, bufS.length, address, PORT_SERVEUR);
            socket.send(packetS);

            byte[] bufR = new byte[8192]; // Buffer un peu plus grand pour les historiques
            DatagramPacket packetR = new DatagramPacket(bufR, bufR.length);
            socket.receive(packetR);
            return new String(packetR.getData(), 0, packetR.getLength()).trim();
        } catch (SocketTimeoutException e) {
            return "timeout";
        } catch (IOException e) {
            e.printStackTrace();
            return "erreur";
        }
    }

    private void envoyerSansAttente(String msg) {
        try {
            byte[] bufS = msg.getBytes();
            DatagramPacket packetS = new DatagramPacket(bufS, bufS.length, address, PORT_SERVEUR);
            socket.send(packetS);
        } catch (IOException e) { e.printStackTrace(); }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ClientGraphique());
    }
}