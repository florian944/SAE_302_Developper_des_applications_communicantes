package com.example.sae302.ui.groupes;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.sae302.Groupes;
import com.example.sae302.MainActivity;
import com.example.sae302.UdpClient;
import com.example.sae302.GroupChatActivity;
import com.example.sae302.databinding.FragmentGroupesBinding;

import java.util.ArrayList;
import java.util.List;

public class GroupesFragment extends Fragment {

    private FragmentGroupesBinding binding;
    private List<Groupes> listeDesGroupes;
    private GroupesAdapter adapter;
    private String monLogin;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        binding = FragmentGroupesBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        if (getActivity() instanceof MainActivity) {
            monLogin = ((MainActivity) getActivity()).getUserLogin();
        }

        listeDesGroupes = new ArrayList<>();

        binding.recyclerViewGroupes.setLayoutManager(new LinearLayoutManager(getContext()));

        adapter = new GroupesAdapter(listeDesGroupes, new GroupesAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(Groupes groupes) {
                Intent intent = new Intent(getActivity(), GroupChatActivity.class);
                intent.putExtra("NOM_GROUPE", groupes.getNom());
                intent.putExtra("USER_LOGIN", monLogin);
                startActivity(intent);
            }

            @Override
            public void onItemLongClick(Groupes groupes) {
                chargerAmisEtOuvrirPopup(groupes);
            }
        });

        binding.recyclerViewGroupes.setAdapter(adapter);
        binding.btnCreateGroup.setOnClickListener(v -> afficherPopupCreationGroupe());

        chargerMesGroupes();

        return root;
    }

    private void chargerMesGroupes() {
        String cmd = "req_mes_groupes," + monLogin;
        UdpClient.sendAndReceive(cmd, new UdpClient.UdpListener() {
            @Override
            public void onReceive(String response) {
                if (getActivity() != null) {
                    getActivity().runOnUiThread(() -> {
                        if (response != null && response.startsWith("mes_groupes_reponse")) {
                            String[] parts = response.split(",");
                            listeDesGroupes.clear();
                            for(int i=1; i<parts.length; i++) {
                                if(!parts[i].trim().isEmpty()) listeDesGroupes.add(new Groupes(parts[i].trim()));
                            }
                            adapter.notifyDataSetChanged();
                        }
                    });
                }
            }
        });
    }

    private void chargerAmisEtOuvrirPopup(Groupes groupeSelectionne) {
        String message = "liste_amis," + monLogin;
        UdpClient.sendAndReceive(message, new UdpClient.UdpListener() {
            @Override
            public void onReceive(String reponseServeur) {
                if (getActivity() != null) {
                    getActivity().runOnUiThread(() -> {
                        if (reponseServeur != null && reponseServeur.startsWith("liste_amis_reponse")) {
                            String[] parts = reponseServeur.split(",");
                            List<String> vraisAmis = new ArrayList<>();
                            for (int i = 1; i < parts.length; i++) {
                                if (!parts[i].trim().isEmpty()) vraisAmis.add(parts[i].trim());
                            }
                            afficherPopupAvecSpinner(groupeSelectionne, vraisAmis);
                        } else {
                            Toast.makeText(getContext(), "Aucun ami trouvé.", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }
        });
    }

    private void afficherPopupAvecSpinner(Groupes groupe, List<String> amis) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        builder.setTitle("Ajouter un membre à : " + groupe.getNom());
        builder.setMessage("Sélectionnez l'ami :");

        final Spinner spinner = new Spinner(getContext());
        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_spinner_item, amis);
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(spinnerAdapter);

        builder.setView(spinner);

        builder.setPositiveButton("Ajouter", (dialog, which) -> {
            if (spinner.getSelectedItem() != null) {
                String amiChoisi = spinner.getSelectedItem().toString();
                String cmd = "ajouter_membre_groupe," + groupe.getNom() + "," + amiChoisi;
                UdpClient.sendAndReceive(cmd, null);
                Toast.makeText(getContext(), amiChoisi + " ajouté !", Toast.LENGTH_SHORT).show();
            }
        });
        builder.setNegativeButton("Annuler", null);
        builder.show();
    }

    private void afficherPopupCreationGroupe() {
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        builder.setTitle("Nouveau Groupe");
        final EditText input = new EditText(getContext());
        input.setHint("Nom du groupe");
        builder.setView(input);

        builder.setPositiveButton("Créer", (dialog, which) -> {
            String nomGroupe = input.getText().toString();
            if (!nomGroupe.isEmpty()) {
                String cmd = "creer_groupe," + monLogin + "," + nomGroupe;
                UdpClient.sendAndReceive(cmd, null);
                listeDesGroupes.add(new Groupes(nomGroupe));
                adapter.notifyDataSetChanged();
                Toast.makeText(getContext(), "Groupe créé !", Toast.LENGTH_SHORT).show();
            }
        });
        builder.setNegativeButton("Annuler", null);
        builder.show();
    }

    @Override
    public void onDestroyView() { super.onDestroyView(); binding = null; }
}