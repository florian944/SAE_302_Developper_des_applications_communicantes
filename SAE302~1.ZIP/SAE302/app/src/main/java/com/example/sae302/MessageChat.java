package com.example.sae302;

public class MessageChat {
    private String texte;
    private boolean estMoi;

    public MessageChat(String texte, boolean estMoi) {
        this.texte = texte;
        this.estMoi = estMoi;
    }

    public String getTexte() {
        return texte;
    }

    public boolean isEstMoi() {
        return estMoi;
    }
}