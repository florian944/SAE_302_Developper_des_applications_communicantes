package com.example.sae302.ui.groupes;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.sae302.Groupes;
import java.util.List;

public class GroupesAdapter extends RecyclerView.Adapter<GroupesAdapter.GroupesViewHolder> {

    private List<Groupes> listeGroupes;
    private OnItemClickListener listener;

    public interface OnItemClickListener {
        void onItemClick(Groupes groupes);
        void onItemLongClick(Groupes groupes);
    }

    public GroupesAdapter(List<Groupes> listeGroupes, OnItemClickListener listener) {
        this.listeGroupes = listeGroupes;
        this.listener = listener;
    }

    @NonNull
    @Override
    public GroupesViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(android.R.layout.simple_list_item_1, parent, false);
        return new GroupesViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull GroupesViewHolder holder, int position) {
        Groupes groupe = listeGroupes.get(position);
        holder.textViewNom.setText(groupe.getNom());

        holder.itemView.setOnClickListener(v -> listener.onItemClick(groupe));

        holder.itemView.setOnLongClickListener(v -> {
            listener.onItemLongClick(groupe);
            return true;
        });
    }

    @Override
    public int getItemCount() {
        return listeGroupes.size();
    }

    static class GroupesViewHolder extends RecyclerView.ViewHolder {
        TextView textViewNom;
        public GroupesViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewNom = itemView.findViewById(android.R.id.text1);
        }
    }
}