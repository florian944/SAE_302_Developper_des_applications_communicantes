package com.example.sae302.ui.messages;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.sae302.R;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class ConversationsAdapter extends ArrayAdapter<String> {

    private Context context;
    private int resource;
    private ConversationListener listener;
    private Set<String> amisAvecNotif = new HashSet<>();
    public interface ConversationListener {
        void onOpen(String ami);
        void onDelete(String ami);
    }

    public ConversationsAdapter(@NonNull Context context, int resource, @NonNull List<String> objects, ConversationListener listener) {
        super(context, resource, objects);
        this.context = context;
        this.resource = resource;
        this.listener = listener;
    }


    public void updateNotifications(Set<String> notifs) {
        this.amisAvecNotif.clear();
        this.amisAvecNotif.addAll(notifs);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        String amiName = getItem(position);

        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(resource, parent, false);
        }

        TextView tvName = convertView.findViewById(R.id.tvAmiName);
        Button btnDelete = convertView.findViewById(R.id.btnDeleteConversation);
        View badge = convertView.findViewById(R.id.viewNotifBadge); // Le point rouge

        tvName.setText(amiName);
        btnDelete.setVisibility(View.GONE);

        if (amisAvecNotif.contains(amiName)) {
            badge.setVisibility(View.VISIBLE);
        } else {
            badge.setVisibility(View.GONE);
        }

        convertView.setOnClickListener(v -> {
            if (listener != null) listener.onOpen(amiName);
        });

        convertView.setOnLongClickListener(v -> {
            if (btnDelete.getVisibility() == View.GONE) {
                btnDelete.setVisibility(View.VISIBLE);
            } else {
                btnDelete.setVisibility(View.GONE);
            }
            return true;
        });

        btnDelete.setOnClickListener(v -> {
            if (listener != null) listener.onDelete(amiName);
        });

        return convertView;
    }
}