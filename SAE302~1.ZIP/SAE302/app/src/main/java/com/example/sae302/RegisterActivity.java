package com.example.sae302;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

// ATTENTION : Si votre XML s'appelle activity_register.xml, gardez ActivityRegisterBinding.
// Si votre XML s'appelle activity_signup.xml, mettez ActivitySignupBinding.
import com.example.sae302.databinding.ActivityRegisterBinding;

public class RegisterActivity extends AppCompatActivity {

    private ActivityRegisterBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityRegisterBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        binding.btnValiderRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String login = binding.etRegisterLogin.getText().toString().trim();
                String password = binding.etRegisterPassword.getText().toString().trim();

                if (login.isEmpty() || password.isEmpty()) {
                    Toast.makeText(RegisterActivity.this, "Veuillez remplir tous les champs", Toast.LENGTH_SHORT).show();
                    return;
                }
                String message = "inscription," + login + "," + password;
                UdpClient.sendAndReceive(message, new UdpClient.UdpListener() {
                    @Override
                    public void onReceive(String response) {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                if (response != null && !response.toLowerCase().contains("erreur")) {
                                    Toast.makeText(RegisterActivity.this, "Compte créé ! Connectez-vous.", Toast.LENGTH_LONG).show();
                                    finish();
                                } else {
                                    Toast.makeText(RegisterActivity.this, "Erreur serveur : " + response, Toast.LENGTH_LONG).show();
                                }
                            }
                        });
                    }
                });
            }
        });
    }
}