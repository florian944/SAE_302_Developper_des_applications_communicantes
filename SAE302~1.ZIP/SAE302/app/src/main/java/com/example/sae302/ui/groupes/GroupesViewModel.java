package com.example.sae302.ui.groupes;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class GroupesViewModel extends ViewModel {

    private final MutableLiveData<String> mText;

    public GroupesViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("page groupes");
    }

    public LiveData<String> getText() {
        return mText;
    }
}