package com.example.sae302;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class PrivateChatActivity extends AppCompatActivity {

    private String destinataire;
    private String monLogin;

    private ListView listView;
    private EditText etMessage;
    private Button btnEnvoyer;
    private ImageButton btnRetour;
    private TextView tvTitre;

    private ArrayList<MessageChat> messagesList;
    private ChatAdapter adapter;

    private boolean actif = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_private_chat);

        destinataire = getIntent().getStringExtra("AMI_LOGIN");
        monLogin = getIntent().getStringExtra("MON_LOGIN");

        tvTitre = findViewById(R.id.tvDestinataire);
        tvTitre.setText(destinataire);

        btnRetour = findViewById(R.id.btnRetourPrive);
        listView = findViewById(R.id.lvMessagesPrive);
        etMessage = findViewById(R.id.etMessagePrive);
        btnEnvoyer = findViewById(R.id.btnEnvoyerPrive);

        messagesList = new ArrayList<>();
        adapter = new ChatAdapter(this, messagesList);
        listView.setAdapter(adapter);

        btnRetour.setOnClickListener(v -> finish());


        btnEnvoyer.setOnClickListener(v -> {
            String msg = etMessage.getText().toString().trim();
            if (!msg.isEmpty()) {

                String cmd = "envoyer_msg_prive," + monLogin + "," + destinataire + "," + msg;
                UdpClient.sendAndReceive(cmd, null);

                messagesList.add(new MessageChat(msg, true));
                adapter.notifyDataSetChanged();
                scrollAuDernierMessage();

                etMessage.setText("");
                chargerMessages();
            }
        });

        lancerLectureAutomatique();
    }

    private void lancerLectureAutomatique() {
        new Thread(() -> {
            while (actif) {
                chargerMessages();
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }

    private void chargerMessages() {
        String cmd = "req_msg_prive," + monLogin + "," + destinataire;

        UdpClient.sendAndReceive(cmd, new UdpClient.UdpListener() {
            @Override
            public void onReceive(String response) {
                runOnUiThread(() -> {
                    if (response != null && response.startsWith("rep_msg_prive")) {

                        String[] parts = response.split(",", 2);

                        if (parts.length > 1 && !parts[1].trim().isEmpty()) {
                            String[] rawMessages = parts[1].split("\\|");

                            messagesList.clear();

                            for (String rawMsg : rawMessages) {
                                boolean estMoi = false;
                                String texteEpure = rawMsg;

                                if (rawMsg.startsWith(monLogin + ":")) {
                                    estMoi = true;
                                    texteEpure = rawMsg.substring((monLogin + ":").length()).trim();
                                } else if (rawMsg.startsWith(destinataire + ":")) {
                                    estMoi = false;
                                    texteEpure = rawMsg.substring((destinataire + ":").length()).trim();
                                } else {
                                    texteEpure = rawMsg;
                                    estMoi = false;
                                }

                                messagesList.add(new MessageChat(texteEpure, estMoi));
                            }
                            adapter.notifyDataSetChanged();
                        }
                    }
                });
            }
        });
    }

    private void scrollAuDernierMessage() {
        if (adapter.getCount() > 0) {
            listView.setSelection(adapter.getCount() - 1);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        actif = false;
    }
}