package com.example.sae302;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

public class UdpClient {

    private static final String SERVER_IP = "10.0.2.2";
    private static final int SERVER_PORT = 3333;

    public interface UdpListener {
        void onReceive(String message);
    }

    public static void sendAndReceive(final String message, final UdpListener listener) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                DatagramSocket socket = null;
                String response = "";
                try {
                    socket = new DatagramSocket();
                    socket.setSoTimeout(5000);

                    InetAddress serverAddr = InetAddress.getByName(SERVER_IP);
                    byte[] sendData = message.getBytes();
                    DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, serverAddr, SERVER_PORT);
                    socket.send(sendPacket);

                    if (listener != null) {
                        byte[] receiveData = new byte[2048];
                        DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
                        socket.receive(receivePacket);
                        response = new String(receivePacket.getData(), 0, receivePacket.getLength());
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                    response = "Erreur: " + e.getMessage();
                } finally {
                    if (socket != null && !socket.isClosed()) {
                        socket.close();
                    }
                }

                if (listener != null) {
                    listener.onReceive(response);
                }
            }
        }).start();
    }
}