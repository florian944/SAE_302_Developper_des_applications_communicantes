package com.example.sae302.ui.messages;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import com.example.sae302.MainActivity;
import com.example.sae302.PrivateChatActivity;
import com.example.sae302.R;
import com.example.sae302.UdpClient;
import com.example.sae302.databinding.FragmentMessagesBinding;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class MessagesFragment extends Fragment {

    private FragmentMessagesBinding binding;
    private String monLogin;
    private List<String> conversationsActives;
    private ConversationsAdapter adapter;
    private Set<String> unreadSet = new HashSet<>();
    private static final String PREFS_NAME = "MyChatPrefs";
    private Handler handler = new Handler(Looper.getMainLooper());
    private Runnable runnableVerification;
    private boolean fragmentActif = false;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        binding = FragmentMessagesBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        if (getActivity() instanceof MainActivity) {
            monLogin = ((MainActivity) getActivity()).getUserLogin();
        }

        conversationsActives = new ArrayList<>();
        chargerConversationsSauvegardees();

        adapter = new ConversationsAdapter(getContext(), R.layout.item_conversation, conversationsActives, new ConversationsAdapter.ConversationListener() {
            @Override
            public void onOpen(String ami) {
                marquerCommeLu(ami);
                ouvrirConversation(ami);
            }

            @Override
            public void onDelete(String ami) {
                supprimerConversation(ami);
            }
        });

        binding.lvConversations.setAdapter(adapter);
        binding.btnNewMessage.setOnClickListener(v -> chargerListeAmisEtAfficherPopup());
        lancerDetectionMessages();

        return root;
    }
    private void verifierHistoriqueAvec(String ami) {
        UdpClient.sendAndReceive("req_msg_prive," + monLogin + "," + ami, response -> {
            if (getActivity() != null && response != null && response.startsWith("rep_msg_prive")) {
                String[] parts = response.split(",", 2);

                if (parts.length > 1 && !parts[1].trim().isEmpty()) {
                    String historiqueComplet = parts[1];
                    int tailleActuelle = historiqueComplet.length();
                    SharedPreferences prefs = getActivity().getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
                    int derniereTailleConnue = prefs.getInt("taille_historique_" + monLogin + "_" + ami, 0);

                    if (tailleActuelle > derniereTailleConnue) {
                        String[] lesMessages = historiqueComplet.split("\\|");
                        String dernierMessage = lesMessages[lesMessages.length - 1];

                        if (dernierMessage.startsWith(monLogin + ":")) {
                            getActivity().runOnUiThread(() -> {
                                SharedPreferences.Editor editor = prefs.edit();
                                editor.putInt("taille_historique_" + monLogin + "_" + ami, tailleActuelle);
                                editor.apply();
                            });
                        }

                        else {
                            getActivity().runOnUiThread(() -> {
                                if (!conversationsActives.contains(ami)) {
                                    ajouterConversation(ami);
                                }
                                if (!unreadSet.contains(ami)) {
                                    unreadSet.add(ami);
                                    adapter.updateNotifications(unreadSet);
                                }
                            });
                        }
                    }
                }
            }
        });
    }

    private void marquerCommeLu(String ami) {
        if (unreadSet.contains(ami)) {
            unreadSet.remove(ami);
            adapter.updateNotifications(unreadSet);
        }
        UdpClient.sendAndReceive("req_msg_prive," + monLogin + "," + ami, response -> {
            if (response != null && response.startsWith("rep_msg_prive")) {
                String[] parts = response.split(",", 2);
                if (parts.length > 1) {
                    int tailleActuelle = parts[1].length();
                    if(getActivity() != null) {
                        SharedPreferences.Editor editor = getActivity().getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit();
                        editor.putInt("taille_historique_" + monLogin + "_" + ami, tailleActuelle);
                        editor.apply();
                    }
                }
            }
        });
    }
    private void lancerDetectionMessages() {
        runnableVerification = new Runnable() {
            @Override
            public void run() {
                if (!fragmentActif || getContext() == null) return;

                UdpClient.sendAndReceive("liste_amis," + monLogin, response -> {
                    if (getActivity() != null && response != null && response.startsWith("liste_amis_reponse")) {
                        String[] parts = response.split(",");
                        for (int i = 1; i < parts.length; i++) {
                            String amiPotentiel = parts[i].trim();
                            if (!amiPotentiel.isEmpty()) {
                                verifierHistoriqueAvec(amiPotentiel);
                            }
                        }
                    }
                });
                handler.postDelayed(this, 3000); // Vérifie toutes les 3 sec
            }
        };
        handler.post(runnableVerification);
    }
    private void chargerConversationsSauvegardees() {
        SharedPreferences settings = getActivity().getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        Set<String> set = settings.getStringSet("conversations_" + monLogin, new HashSet<>());
        conversationsActives.clear();
        conversationsActives.addAll(set);
    }
    private void sauvegarderConversations() {
        SharedPreferences settings = getActivity().getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = settings.edit();
        Set<String> set = new HashSet<>(conversationsActives);
        editor.putStringSet("conversations_" + monLogin, set);
        editor.apply();
    }

    private void ajouterConversation(String ami) {
        if (!conversationsActives.contains(ami)) {
            conversationsActives.add(ami);
            adapter.notifyDataSetChanged();
            sauvegarderConversations();
        }
    }

    private void supprimerConversation(String ami) {
        conversationsActives.remove(ami);
        unreadSet.remove(ami);
        adapter.updateNotifications(unreadSet);
        adapter.notifyDataSetChanged();
        sauvegarderConversations();
        Toast.makeText(getContext(), "Conversation masquée", Toast.LENGTH_SHORT).show();
    }

    private void chargerListeAmisEtAfficherPopup() {
        UdpClient.sendAndReceive("liste_amis," + monLogin, response -> {
            if (getActivity() != null) {
                getActivity().runOnUiThread(() -> {
                    if (response != null && response.startsWith("liste_amis_reponse")) {
                        String[] parts = response.split(",");
                        List<String> tousMesAmis = new ArrayList<>();
                        for (int i = 1; i < parts.length; i++) {
                            if (!parts[i].trim().isEmpty()) {
                                tousMesAmis.add(parts[i].trim());
                            }
                        }
                        afficherPopupChoixAmi(tousMesAmis);
                    } else {
                        Toast.makeText(getContext(), "Impossible de charger les amis", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });
    }

    private void afficherPopupChoixAmi(List<String> amis) {
        if (amis.isEmpty()) {
            Toast.makeText(getContext(), "Ajoutez d'abord des amis !", Toast.LENGTH_SHORT).show();
            return;
        }
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        builder.setTitle("Nouvelle conversation avec :");
        String[] amisArray = amis.toArray(new String[0]);
        builder.setItems(amisArray, (dialog, which) -> {
            String amiChoisi = amisArray[which];
            marquerCommeLu(amiChoisi);
            ajouterConversation(amiChoisi);
            ouvrirConversation(amiChoisi);
        });
        builder.setNegativeButton("Annuler", null);
        builder.show();
    }

    private void ouvrirConversation(String amiLogin) {
        Intent intent = new Intent(getActivity(), PrivateChatActivity.class);
        intent.putExtra("AMI_LOGIN", amiLogin);
        intent.putExtra("MON_LOGIN", monLogin);
        startActivity(intent);
    }

    @Override
    public void onResume() {
        super.onResume();
        fragmentActif = true;
        if(runnableVerification != null) handler.removeCallbacks(runnableVerification);
        lancerDetectionMessages();
    }

    @Override
    public void onPause() {
        super.onPause();
        fragmentActif = false;
        if (runnableVerification != null) handler.removeCallbacks(runnableVerification);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}