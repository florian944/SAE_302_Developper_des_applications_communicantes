package com.example.sae302.ui.amis;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class AmisViewModel extends ViewModel {

    private final MutableLiveData<String> mText;

    public AmisViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("page amis");
    }

    public LiveData<String> getText() {
        return mText;
    }
}