package com.example.sae302;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

public class ChatAdapter extends ArrayAdapter<MessageChat> {

    public ChatAdapter(@NonNull Context context, List<MessageChat> messages) {
        super(context, 0, messages);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        MessageChat message = getItem(position);

        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.item_message_chat, parent, false);
        }

        LinearLayout layoutMoi = convertView.findViewById(R.id.layout_moi);
        LinearLayout layoutAmi = convertView.findViewById(R.id.layout_ami);
        TextView tvMoi = convertView.findViewById(R.id.tvMessageMoi);
        TextView tvAmi = convertView.findViewById(R.id.tvMessageAmi);

        if (message.isEstMoi()) {
            layoutMoi.setVisibility(View.VISIBLE);
            layoutAmi.setVisibility(View.GONE);
            tvMoi.setText(message.getTexte());
        } else {
            layoutMoi.setVisibility(View.GONE);
            layoutAmi.setVisibility(View.VISIBLE);
            tvAmi.setText(message.getTexte());
        }

        return convertView;
    }
}