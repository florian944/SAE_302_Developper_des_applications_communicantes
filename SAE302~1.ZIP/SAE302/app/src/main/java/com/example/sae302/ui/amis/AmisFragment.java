package com.example.sae302.ui.amis;

import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.example.sae302.MainActivity; // Importez votre MainActivity
import com.example.sae302.UdpClient;
import com.example.sae302.databinding.FragmentAmisBinding;

public class AmisFragment extends Fragment {

    private FragmentAmisBinding binding;
    private String monLogin;
    private Handler handler = new Handler(Looper.getMainLooper());
    private Runnable boucleLecture;
    private boolean fragmentActif = false;
    private String nomDemandeurEnAttente = null;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        binding = FragmentAmisBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        if (getActivity() instanceof MainActivity) {
            monLogin = ((MainActivity) getActivity()).getUserLogin();
        }

        binding.tvWelcome.setText("Espace Amis de " + monLogin);
        binding.btnInvite.setOnClickListener(v -> {
            String ami = binding.etFriendName.getText().toString().trim();
            if (!ami.isEmpty()) {
                UdpClient.sendAndReceive("demande_ami," + monLogin + "," + ami, null);
                Toast.makeText(getContext(), "Envoyé à " + ami, Toast.LENGTH_SHORT).show();
                binding.etFriendName.setText("");
            }
        });
        binding.btnAccept.setOnClickListener(v -> {
            if (nomDemandeurEnAttente == null) {
                Toast.makeText(getContext(), "Rien à accepter", Toast.LENGTH_SHORT).show();
            } else if (!binding.cbSelectRequest.isChecked()) {
                Toast.makeText(getContext(), "Cochez la case !", Toast.LENGTH_SHORT).show();
            } else {
                UdpClient.sendAndReceive("demande_ami_accepte," + monLogin + "," + nomDemandeurEnAttente, null);
                Toast.makeText(getContext(), "Ami ajouté !", Toast.LENGTH_SHORT).show();
                cacherLaDemande();
                mettreAJourListeAmis();
            }
        });
        binding.btnRefuse.setOnClickListener(v -> {
            if (nomDemandeurEnAttente != null) cacherLaDemande();
        });

        return root;
    }

    private void afficherUneDemande(String nomAmi) {
        nomDemandeurEnAttente = nomAmi;
        binding.tvRequestSenderName.setText(nomAmi);
        binding.cbSelectRequest.setChecked(false);
        binding.layoutRequestContainer.setVisibility(View.VISIBLE);
    }

    private void cacherLaDemande() {
        nomDemandeurEnAttente = null;
        binding.layoutRequestContainer.setVisibility(View.GONE);
    }

    private void mettreAJourListeAmis() {
        if(getContext() == null) return;

        UdpClient.sendAndReceive("liste_amis," + monLogin, new UdpClient.UdpListener() {
            @Override
            public void onReceive(final String response) {
                if (getActivity() != null) {
                    getActivity().runOnUiThread(() -> {
                        if (binding == null) return;

                        if (response != null && response.startsWith("liste_amis_reponse")) {
                            String[] parts = response.split(",");
                            binding.llFriendsContainer.removeAllViews();

                            if (parts.length <= 1) {
                                TextView tvEmpty = new TextView(getContext());
                                tvEmpty.setText("Vous n'avez pas encore d'amis.");
                                binding.llFriendsContainer.addView(tvEmpty);
                            } else {
                                for (int i = 1; i < parts.length; i++) {
                                    final String nomAmi = parts[i];

                                    TextView tvNom = new TextView(getContext());
                                    tvNom.setText("• " + nomAmi);
                                    tvNom.setTextSize(18);
                                    tvNom.setTextColor(Color.BLACK);
                                    tvNom.setPadding(0, 10, 0, 10);

                                    final Button btnDelete = new Button(getContext());
                                    btnDelete.setText("Supprimer " + nomAmi);
                                    btnDelete.setBackgroundColor(Color.RED);
                                    btnDelete.setTextColor(Color.WHITE);
                                    btnDelete.setVisibility(View.GONE);

                                    tvNom.setOnClickListener(v -> {
                                        if (btnDelete.getVisibility() == View.VISIBLE) {
                                            btnDelete.setVisibility(View.GONE);
                                        } else {
                                            btnDelete.setVisibility(View.VISIBLE);
                                        }
                                    });

                                    btnDelete.setOnClickListener(v -> {
                                        UdpClient.sendAndReceive("supprimer_ami," + monLogin + "," + nomAmi, null);
                                        Toast.makeText(getContext(), nomAmi + " supprimé", Toast.LENGTH_SHORT).show();
                                        mettreAJourListeAmis();
                                    });

                                    binding.llFriendsContainer.addView(tvNom);
                                    binding.llFriendsContainer.addView(btnDelete);

                                    View line = new View(getContext());
                                    line.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1));
                                    line.setBackgroundColor(Color.LTGRAY);
                                    binding.llFriendsContainer.addView(line);
                                }
                            }
                        }
                    });
                }
            }
        });
    }

    private void demarrerBoucle() {
        boucleLecture = new Runnable() {
            @Override
            public void run() {
                if (!fragmentActif || getContext() == null) return;

                UdpClient.sendAndReceive("lecture," + monLogin, new UdpClient.UdpListener() {
                    @Override
                    public void onReceive(final String response) {
                        if (getActivity() != null) {
                            getActivity().runOnUiThread(() -> {
                                if (binding == null) return;

                                if (response != null && !response.trim().equals("rien") && !response.isEmpty()) {
                                    if (response.contains("Demande ami")) {
                                        String nom = response.replace("Demande ami de: ", "");
                                        if (nomDemandeurEnAttente == null || !nomDemandeurEnAttente.equals(nom)) {
                                            afficherUneDemande(nom);
                                        }
                                    } else {
                                        binding.tvMessagesList.setText(response);
                                    }
                                }
                            });
                        }
                    }
                });

                mettreAJourListeAmis();
                handler.postDelayed(this, 5000);
            }
        };
        handler.post(boucleLecture);
    }

    @Override
    public void onResume() {
        super.onResume();
        fragmentActif = true;
        demarrerBoucle();
    }

    @Override
    public void onPause() {
        super.onPause();
        fragmentActif = false;
        if (boucleLecture != null) handler.removeCallbacks(boucleLecture);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}