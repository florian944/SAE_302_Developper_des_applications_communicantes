package com.example.sae302;

public class Groupes {
    private String nom;

    public Groupes(String nom) {
        this.nom = nom;
    }

    public String getNom() {
        return nom;
    }
}