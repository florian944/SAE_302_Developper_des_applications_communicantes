package com.example.sae302;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class GroupChatActivity extends AppCompatActivity {

    private String nomGroupe;
    private String userLogin;

    private ListView listViewMessages;
    private EditText etMessage;
    private Button btnEnvoyer;
    private ImageButton btnRetour;
    private TextView tvTitre;

    private ArrayList<String> messagesList;
    private ArrayAdapter<String> adapter;

    private boolean actif = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_group_chat);

        nomGroupe = getIntent().getStringExtra("NOM_GROUPE");
        userLogin = getIntent().getStringExtra("USER_LOGIN");

        tvTitre = findViewById(R.id.tvNomGroupe);
        tvTitre.setText(nomGroupe);

        btnRetour = findViewById(R.id.btnRetourGroup);
        listViewMessages = findViewById(R.id.listViewMessages);
        etMessage = findViewById(R.id.etMessage);
        btnEnvoyer = findViewById(R.id.btnEnvoyer);

        messagesList = new ArrayList<>();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, messagesList);
        listViewMessages.setAdapter(adapter);

        btnRetour.setOnClickListener(v -> {
            finish();
        });

        btnEnvoyer.setOnClickListener(v -> envoyerMessage());

        lancerLectureAutomatique();
    }

    private void envoyerMessage() {
        String texte = etMessage.getText().toString().trim();
        if (!texte.isEmpty()) {
            String cmd = "envoyer_msg_groupe," + userLogin + "," + nomGroupe + "," + texte;
            UdpClient.sendAndReceive(cmd, null);
            etMessage.setText("");
            chargerMessages();
        }
    }

    private void lancerLectureAutomatique() {
        new Thread(() -> {
            while (actif) {
                chargerMessages();
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }

    private void chargerMessages() {
        String cmd = "req_msg_groupe," + nomGroupe;

        UdpClient.sendAndReceive(cmd, new UdpClient.UdpListener() {
            @Override
            public void onReceive(String response) {
                runOnUiThread(() -> {
                    if (response != null && response.startsWith("rep_msg_groupe")) {
                        String[] parts = response.split(",", 2);
                        if (parts.length > 1) {
                            String historiqueComplet = parts[1];
                            if (!historiqueComplet.trim().isEmpty()) {
                                String[] lesMessages = historiqueComplet.split("\\|");
                                messagesList.clear();
                                for (String msg : lesMessages) {
                                    messagesList.add(msg);
                                }
                                adapter.notifyDataSetChanged();
                            }
                        }
                    }
                });
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        actif = false;
    }
}